package ru.privateblocks;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Пишет игроку «Вы вторглись в регион ...», когда он заходит в чужой приват. */
public class IntrusionListener implements Listener {

    private final PrivateBlocks plugin;
    /** игрок -> регион, в котором он находился на прошлом шаге */
    private final Map<UUID, UUID> last = new HashMap<>();

    public IntrusionListener(PrivateBlocks plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (Objects.equals(from.getWorld(), to.getWorld())
                && from.getBlockX() == to.getBlockX()
                && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) {
            return; // остались в том же блоке
        }

        Player p = e.getPlayer();
        Region r = plugin.regions().getAt(to);
        UUID current = r == null ? null : r.id;
        UUID previous = last.get(p.getUniqueId());
        if (Objects.equals(current, previous)) return;

        if (current == null) {
            last.remove(p.getUniqueId());
        } else {
            last.put(p.getUniqueId(), current);
        }

        if (r == null || r.isMember(p.getUniqueId()) || plugin.canBypass(p)) return;

        String name = r.name == null
                ? plugin.getConfig().getString("messages.no-name", "без названия")
                : r.name;
        String owner = String.valueOf(Bukkit.getOfflinePlayer(r.owner).getName());

        p.sendMessage(plugin.msg("intrusion", "%name%", name, "%owner%", owner));

        if (plugin.getConfig().getBoolean("intrusion-title-enabled", true)) {
            String title = plugin.getConfig().getString("messages.intrusion-title", "&c&lВторжение!");
            String sub = plugin.getConfig().getString("messages.intrusion-subtitle", "&7%name% &8• &7%owner%")
                    .replace("%name%", name).replace("%owner%", owner);
            p.sendTitle(PrivateBlocks.color(title), PrivateBlocks.color(sub), 5, 40, 10);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        last.remove(e.getPlayer().getUniqueId());
    }
}
