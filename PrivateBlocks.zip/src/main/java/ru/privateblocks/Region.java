package ru.privateblocks;

import org.bukkit.Location;
import org.bukkit.block.Block;

import java.util.*;

public class Region {

    public static final List<String> ALL_FLAGS = List.of("build", "interact", "pvp", "explosion", "fire");

    public final UUID id;
    public final UUID owner;
    public final Set<UUID> members = new HashSet<>();
    public final String world;
    public final int x, y, z, radius;
    public final String type;
    public final boolean fullHeight;
    public final Map<String, Boolean> flags = new HashMap<>();
    public String name; // необязательное название региона
    public int tntHits;  // сколько TNT уже взорвалось у региона

    public Region(UUID id, UUID owner, String world, int x, int y, int z, int radius, String type, boolean fullHeight) {
        this.id = id;
        this.owner = owner;
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.radius = radius;
        this.type = type;
        this.fullHeight = fullHeight;
    }

    public boolean flag(String name) {
        return flags.getOrDefault(name, false);
    }

    public boolean isMember(UUID uuid) {
        return owner.equals(uuid) || members.contains(uuid);
    }

    public boolean isCenter(Block b) {
        return b.getWorld().getName().equals(world) && b.getX() == x && b.getY() == y && b.getZ() == z;
    }

    public boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        if (Math.abs(l.getBlockX() - x) > radius || Math.abs(l.getBlockZ() - z) > radius) return false;
        return fullHeight || Math.abs(l.getBlockY() - y) <= radius;
    }

    public boolean intersects(Region o) {
        if (!world.equals(o.world)) return false;
        int r = radius + o.radius;
        if (Math.abs(x - o.x) > r || Math.abs(z - o.z) > r) return false;
        if (fullHeight || o.fullHeight) return true;
        return Math.abs(y - o.y) <= r;
    }
}
